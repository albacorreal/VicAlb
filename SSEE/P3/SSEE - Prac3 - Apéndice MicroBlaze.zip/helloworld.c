/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 115200.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   115200
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xparameters.h"
#include "xiomodule.h"

// Variable para inicializar la E/S. Se pone global
// para que puedan usarla los manejadores de interrupciones
XIOModule iomodule;



// Manejador de Interrupci�n para el FIT1.
// Habr� que conmutar el led de parpadeo cada 0,5 segundos,
// enviando su nuevo valor por el GPO3 cuando haya que cambiarlo.
// Para ello avisaremos al bucle principal de este evento y en �l se tratar�.
// -------------------------
// A RELLENAR POR EL ALUMNO
// -------------------------



// Manejador de Interrupci�n Externa.
// Cuando se indique desde el exterior habr� que atender a este evento,
// que nos indicar� que los resultados ya est�n calculados y hay que
// recibirlos y mostrarlos por pantalla posteriormente.
// Para ello avisaremos al bucle principal de este evento y en �l se tratar�.
// -------------------------
// A RELLENAR POR EL ALUMNO
// -------------------------


int main()
{
	u32 data;

	// Inicializa el micro
	init_platform();


	// Inicializa la E/S para GPI y GPO y el m�dulo de la UART para obtener la direcci�n base:
	data = XIOModule_Initialize(&iomodule, XPAR_IOMODULE_0_DEVICE_ID);
	data = XIOModule_Start(&iomodule);
	data = XIOModule_CfgInitialize(&iomodule, NULL, 1);


	// Inicializaciones para las interrupciones
	// -------------------------
	// A RELLENAR POR EL ALUMNO
	// -------------------------


	// Bucle para env�o de pulsaciones "ficticias" para la simulaci�n completa del circuito
	// -------------------------
	// A RELLENAR POR EL ALUMNO
	// -------------------------


	// Fin de la simulaci�n.
	// Pasamos a operaci�n normal para el resto del programa.
	// -------------------------
	// A RELLENAR POR EL ALUMNO
	// -------------------------


	// Esta l�nea hace que el cursor se vaya arriba a la izquierda y se borre la pantalla
	// xil_printf("\033[H\033[J");

	// Imprime unos mensajes de instrucciones de manejo
	xil_printf("\n\rPrograma de multiplicaci�n de n�meros complejos\n\r");
	xil_printf("Teclee 4 datos entre 0.0 y 9.9. Tras cada dato pulse 'A'\n\r");
	xil_printf ("\t"); // Orden al Remote Lab de enviar todos los printf anteriores a la consola.

    while(1)
	{
    	// Bucle para leer del teclado; comprobar� si ocurre alguno de estos eventos:
    	//
    	// A) El usuario pulse alguna tecla de las que reconocemos para este programa (n�meros del 0 al 9 o la
    	// tecla 'A'). Si se pulsa una tecla no reconocida se vuelve a leer.
    	//
    	// B) Se active la interrupci�n Externa INTC.
    	//
    	// C) Se active la interrupci�n del Temporizador FIT1.



    	// ----------------------------------------------------------
    	// Tratamiento del caso A) El usuario ha pulsado alguna tecla.
    	// ----------------------------------------------------------
    	//
    	// Hay que comprobar qu� tecla es y enviarla hacia el m�dulo de c�lculo.
    	//
    	// Comprobamos cu�l es el car�cter que ha pulsado el usuario compar�ndolo con los c�digos ASCII
    	// que nos interesan, que ser�n de la tecla "0" a la tecla "9", as� como la "A".
    	// Para cada pulsaci�n habr� que generar un c�digo de "cod_tecla_micro(3:0)" oportuno para enviarlo
    	// hacia la FPGA posteriormente y una se�al de sincronismo de �tecla_pulsada_micro�.
    	// Tambi�n habr� que imprimir por pantalla el car�cter tecleado por el usuario para que lo vea,
    	// siempre que sea un n�mero, y el punto decimal cuando corresponda (en la 2� cifra a introducir).
    	// -------------------------
    	// A RELLENAR POR EL ALUMNO
    	// -------------------------
    	//
    	// Enviamos a la FPGA por el puerto GPO1 el valor del c�digo que corresponde,
    	// para que llegue a la FPGA "cod_tecla_micro(3:0)"
    	// -------------------------
    	// A RELLENAR POR EL ALUMNO
    	// -------------------------
    	//
    	// Simulamos un pulso de "tecla_pulsada_micro" escribiendo un "1"
    	// y posteriormente un "0" en el GPO2:
    	// -------------------------
    	// A RELLENAR POR EL ALUMNO
    	// -------------------------
    	//
    	// Volvemos al principio del bucle



    	// -------------------------------------------------------------------
    	// Tratamiento del caso B) Se ha activado la interrupci�n Externa INTC.
    	// -------------------------------------------------------------------
    	//
    	// Hay que leer los resultados y sus signos, y escribirlos por pantalla.
    	//
    	// Leemos los valores de Result_BCD_Real(15:0) y Result_BCD_Imag(15:0) de GPI1.
    	// Leemos los valores de Signo_Real y Signo_Imag de GPI2.
    	// -------------------------
    	// A RELLENAR POR EL ALUMNO
    	// -------------------------
    	//
    	// Hacemos las operaciones l�gicas necesarias a nivel de bit para separar los datos
    	// del puerto GPI1 y los signos del puerto GPI2:
    	// GPI1 --> bits(31:16) --> Result_BCD_Real(15:0) (ser�n decenas, unidades, d�cimas y cent�simas en BCD)
    	// GPI1 --> bits(15:0) --> Result_BCD_Imag(15:0) (ser�n decenas, unidades, d�cimas y cent�simas en BCD)
    	// GPI2 --> bit (0) --> Signo_Imag
    	// GPI2 --> bit (1) --> Signo_Real
    	// -------------------------
    	// A RELLENAR POR EL ALUMNO
    	// -------------------------
    	//
    	// Imprimimos por pantalla los datos le�dos haciendo los "xil_printf" necesarios.
    	// Tener en cuenta que hay que imprimir el signo, las cifras BCD y la coma decimal
    	// en los sitios oportunos.
    	// -------------------------
    	// A RELLENAR POR EL ALUMNO
    	// -------------------------
    	//
    	// Esperamos a que el usuario pulse la letra "C" para volver al inicio
    	// -------------------------
		// A RELLENAR POR EL ALUMNO
		// -------------------------
    	//
    	// Volvemos al principio del bucle



    	// -------------------------------------------------------------------
		// Tratamiento del caso C) Se ha activado la interrupci�n del Temporizador FIT1.
    	// -------------------------------------------------------------------
    	//
    	// Hay que comprobar si han pasado 0,5 segundos desde la �ltima conmutaci�n del led.
    	// En caso negativo no se hace nada y se vuelve al principio del bucle.
    	// En caso positivo, se cambia de valor el led y se env�a por GPO3.
    	// -------------------------
		// A RELLENAR POR EL ALUMNO
		// -------------------------
		//
    	// Volvemos al principio del bucle


	}
	cleanup_platform();
	return 0;
}

// source ipcore_dir/microblaze_mcs_setup.tcl
// microblaze_mcs_data2mem workspace/hello_world/debug/hello_world.elf

