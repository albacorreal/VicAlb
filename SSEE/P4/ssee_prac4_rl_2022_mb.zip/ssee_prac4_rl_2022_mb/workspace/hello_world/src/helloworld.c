/* helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 115200.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   115200
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xparameters.h"
#include "xiomodule.h"
#include <string.h>


// Defino el tipo para las frases
typedef struct {
		char Letra;
		u8 Visible;
	} Caracter_Oculto;

// Defino las frases globales
const char *frases_prep[10] =
		{
		 "PRIMERA FRASE A ACERTAR PREPARADA",
		 "ESTO ES UNA FRASE DE PRUEBA", //"SEGUNDA FRASE"
		 "ESTUDIAR EN LA UNIVERSIDAD DE MALAGA ES UNA MARAVILLA", //""
		 "EL AHORCADO ES UN JUEGO DE ADIVINANZA ", //""
		 "PIENSO Y LUEGO EXISTO", //""
		 "VIVA EL PISTO", //""
		 "EL ZOO MOLA", //""
		 "HACE FALTA UNA VIDA PARA APRENDER A VIVIR", //""
		 "LA PALABRA ELECTROENCEFALOGRAFISTA TIENE EL RECORD DE SER LA PALABRA MAS LARGA DEL CASTELLANO", //""
		 "EL PINGUINUS IMPERIALIS ES UN AVE EXTINTA" //"ESTA ES LA ULTIMA DE LAS FRASES PREPARADAS"
		};

// Defino el tiempo total de juego y el n�mero de fallos m�ximo
const u8 maximo_tiempo = 30; // 30 segundos
const u8 maximo_fallos = 5; // 5 fallos


// Variable para inicializar la E/S. Se pone global
// para que puedan usarla los manejadores de interrupciones
XIOModule iomodule;

// Variable global de tiempo de juego
u8 tiempo_juego = 0;

// Contador para los bucles for
int i;


// Manejador de Interrupci�n para el FIT1.
u8 intc_fit1 = 0;

void Manejador_Int_Temporizador1 (void* ref)
{
	intc_fit1 = 1;
}


// Funci�n para marcar como visibles los caracteres acertados
u8 letra_acertada = 0;

u8 Letra_Acertada (char letra, Caracter_Oculto *frase, u8 longitud)
{
	// Se supone inicialmente que no se ha acertado la letra
	letra_acertada = 0;

	// Se comprueba si alguna de las letras de la frase coincide con la pulsada
	for (i=0; i < longitud; i++)
	{
		// Para marcar como visibles los caracteres acertados solo se tendr�n en cuenta
		// aquellos que aun no son visibles y son iguales a la letra pulsada
		if ((frase[i].Visible == 0) && (frase[i].Letra == letra))
		{
			// La letra pulsada se encuentra en la frase y est� oculta
			// Se marca el carater como visible
			frase[i].Visible = 1;

			// Se indica que se ha acertado la letra
			letra_acertada = 1;
		}
	}
	return letra_acertada;
}


// Funci�n para imprimir en la pantalla la frase ocultando las letras no acertadas
void Imprimir_Frase_Oculta (Caracter_Oculto *frase, u8 longitud)
{
	for (i=0; i < longitud; i++)
	{
		// Comprobar si el caracter es visible o no
		if (frase[i].Visible == 0)
		{
			// El caracter est� oculto, se imprime un asterisco
			xil_printf("*");
		}
		else
		{
			// El caracter es visible, se imprime el caracter
			xil_printf("%c", frase[i].Letra);
		}
	}
	xil_printf("\n");
}


// Funci�n para imprimir en la pantalla la frase al descubierto completa
void Imprimir_Frase_Descubierta (Caracter_Oculto *frase,u8 longitud)
{
	for (i=0; i < longitud; i++)
	{
		// Se imprime el caracter de la posici�n i
		xil_printf("%c", frase[i].Letra);
	}
	xil_printf("\n");
}


int main()
{
	u32 data;
	u8 fin_juego = 0;
	Caracter_Oculto frase[100];	// Variable para guardar la frase a adivinar
	u8 longitud = 0;			// Variable para guardar la longitud de la frase
	u8 letra = 0;				// Variable para guardar la tecla pulsada
	u8 frase_acertada = 0;		// Variable para indicar si se ha acertado la frase
	u8 numero_aciertos = 0;		// Contador del n�mero de aciertos
	u8 numero_fallos = 0;		// Contador del n�mero de fallos

	// Inicializa el micro
	init_platform();


	// Inicializa la E/S para GPI y GPO y el m�dulo de la UART para obtener la direcci�n base:
	data = XIOModule_Initialize(&iomodule, XPAR_IOMODULE_0_DEVICE_ID);
	data = XIOModule_Start(&iomodule);
	data = XIOModule_CfgInitialize(&iomodule, NULL, 1);


	// Inicializaciones para las interrupciones

	// Iniciamos el manejador de interrupciones
	microblaze_register_handler(XIOModule_DeviceInterruptHandler, XPAR_IOMODULE_0_DEVICE_ID);

	// Registramos el manejador de interrupciones para el FIT1 "Manejador_Int_Temporizador1"
	XIOModule_Connect(&iomodule, XIN_IOMODULE_FIT_1_INTERRUPT_INTR, Manejador_Int_Temporizador1, NULL);

	// Activamos la interrupci�n para FIT1
	XIOModule_Enable(&iomodule, XIN_IOMODULE_FIT_1_INTERRUPT_INTR);

	// Activamos Interrupciones
	microblaze_enable_interrupts();


	// Se imprimen unos mensajes de instrucciones de manejo
	xil_printf("\n\rJUEGO DE ADIVINACION DE FRASES\n");
	xil_printf("\n\rDebe adivinar todas las letras que componen la frase");
	xil_printf("\n\rTendr� que ir pulsando los caracteres que crea que se encuentran en la frase");
	xil_printf("\n\rCada vez que acierte un caracter, se mostrar� la frase con dicho caracter visible");
	xil_printf("\n\rTiempo m�ximo de juego: %ds", maximo_tiempo);
	xil_printf("\n\rN�mero m�ximo de fallos: %d", maximo_fallos);
	xil_printf("\n\n\rPulse cualquier tecla para comenzar a jugar\r\n\n");
	//xil_printf("\t");


	// Proceso para escoger una frase aleatoria.
	int index = 0;	// �ndice para indicar la frase obtenida

	// Cuando el usuario interact�e tocando cualquier tecla
	while (data == 0)
	{
		// Se lee un dato del puerto serie
		data = XIOModule_Recv(&iomodule, &letra, 1);

		// Se incrementa el valor del �ndice
		index++;

		// Si el �ndice es '9' se resetea a '0'
		if (index == 9)
		{
			index = 0;
		}
	}

	// Conocida la frase para adivinar, se guarda en "frase"

	// Se obtiene la longitud efectiva de la frase
	longitud = strlen(frases_prep[index]);

	// Se guardan los caracteres en cada posici�n de "frase"
	for (i=0; i < longitud; i++)
	{
		// Se guarda el caracter de la posici�n i en la misma posici�n de "frase"
		frase[i].Letra = frases_prep[index][i];

		// Se marcan como no visibles todos los caracteres menos los espacios
		if (frase[i].Letra != 32)
		{
			// No es un espacio, se marca como no visible
			frase[i].Visible = 0;
		}
		else
		{
			// Es un espacio, se marca como visible
			frase[i].Visible = 1;
		}
	}

	// Se imprime la frase oculta por pantalla
	Imprimir_Frase_Oculta(frase, longitud);
	//xil_printf("\t");



	// Bucle principal
    while(fin_juego == 0)
	{
    	// Bucle principal del juego, comprobaremos al menos los siguiente eventos:
    	//
    	// A) El usuario pulse alguna tecla de las que reconocemos para este programa
    	//    (teclas de la 'A' a la 'Z', may�sculas o min�sculas).
    	//    Si se pulsa una tecla no reconocida no se hace nada.
    	//
    	// B) Se comprueba si se ha acertado toda la frase.
    	//
    	// C) Se comprueba si se ha acabado el tiempo.
    	//
    	// D) Se comprueba si se ha llegado al n�mero m�ximo de fallos.
    	//


    	// ----------------------------------------------------------
    	// Tratamiento del caso A) El usuario ha pulsado alguna tecla.
    	// ----------------------------------------------------------
    	//
    	// Se comprueba si es un car�cter de los aceptados, y si es as�
    	// se mira en la frase a ver si aparece. Si est�, se ponen visibles
    	// todas las repeticiones del mismo y se imprime la parte visible de la frase,
    	// n� de aciertos, n� de fallos y tiempo transcurrido.

    	// Se lee un caracter del puerto serie
    	data = XIOModule_Recv(&iomodule, &letra, 1);

    	// Se comprueba si se ha recibido un dato
    	if (data != 0)
    	{
    		// Se ha pulsado una tecla
    		// Se comprueba si la tecla pulsada es una letra v�lida ('A'-'Z','a'-'z')
    		if (((letra >= 65) && (letra <= 90)) || ((letra >= 97) && (letra <= 122)))
    		{
    			// La tecla pulsada es uno de los caracteres v�lidos
    			// Se comprueba si la letra es min�scula
    			if (((letra >= 97) && (letra <= 122)))
    			{
    				// Se convierte la letra min�scula en may�scula
    			    letra = letra-32;
    			}
    			// Se muestra la letra pulsada por pantalla
    			xil_printf("%c\n\n\r", letra);

    			// Se comprueba si se ha acertado o no la letra
    			if (Letra_Acertada(letra, frase, longitud) == 1)
    			{
    				// Se ha acertado la letra
    				// Se incrementa el contador de aciertos
    				numero_aciertos++;

    				// Se imprime la frase oculta con los nuevos caracteres
    				Imprimir_Frase_Oculta(frase, longitud);

    				// Se imprime el n�mero de aciertos
    				xil_printf("\n\rN�meros de aciertos: %d", numero_aciertos);

    				// Se imprime el n�meros de fallos
    				xil_printf("\n\rN�meros de fallos: %d", numero_fallos);

    				// Se imprime el tiempo empleado
    				xil_printf("\n\rTiempo de juego: %ds\n\n", tiempo_juego);

    				// Se mueve el cursor
    				xil_printf("\033[B");
    	    	}
    			else
    			{
    				// No se ha acertado la letra
    				// Se incrementa el contador de fallos
    				numero_fallos++;

    				// Se indica al jugador introducir un nuevo caracter
    				xil_printf("\n\rIntroduzca otro caracter:  ");
    			}
    		}
    		//xil_printf("\t");
    	}

    	// -------------------------------------------------------------------
    	// Tratamiento del caso B) Comprobamos si ha acertado toda la frase.
    	// -------------------------------------------------------------------
    	//
		// Si toda la frase ya es visible, el jugador ha ganado.
		// Se imprime la frase completa, n� de aciertos, n� de fallos y tiempo transcurrido.

    	// Se comprueba si se ha acertado la frase completa

    	// Se supone inicialmente que la frase ha sido acertada
    	frase_acertada = 1;

    	// Se comprueba si hay alg�n caracter a�n no visible
    	for (i=0; i < longitud; i++)
    	{
    		if (frase[i].Visible == 0)
    		{
    			// Hay un caracter no visible, por tanto, no se ha acertado la frase
    			frase_acertada = 0;
    		}
    	}

    	// En caso de haberse acertado la frase completa
    	if (frase_acertada == 1)
		{
    		// Se ha acertado la frase completa

    		// Se imprime que el jugador ha acertado la frase
    		xil_printf("\n\n\rHas acertado la frase.\n\r");

    		// Se imprime el mensaje de que se ha ganado
    		xil_printf("\n�HAS GANADO!\n");

			// Se imprime la frase en cuesti�n
			xil_printf("\n\rLa frase es:\n\r");
			Imprimir_Frase_Descubierta(frase, longitud);

			// Se imprime el n�mero de aciertos
			xil_printf("\n\rN�meros de aciertos: %d", numero_aciertos);

			// Se imprime el n�meros de fallos
			xil_printf("\n\rN�meros de fallos: %d", numero_fallos);

			// Se imprime el tiempo empleado
			xil_printf("\n\rTiempo de juego: %ds", tiempo_juego);
			//xil_printf("\t");

			// Se indica que el juego ha finalizado
			fin_juego = 1;
		}



    	// -------------------------------------------------------------------
		// Tratamiento del caso C) Comprobamos si ha acabado el tiempo.
    	// -------------------------------------------------------------------
    	//
		// Si hemos superado el tiempo m�ximo de juego, el jugador pierde.
		// Se imprime la frase completa, n� de aciertos, n� de fallos y tiempo transcurrido.

    	// Se comprueba si se ha activado la interrupci�n del FIT1
    	if (intc_fit1 == 1)
    	{
    		// Se comprueba si el tiempo transcurrido a alcanzado el m�ximo
    		if (tiempo_juego == maximo_tiempo)
    		{
    			// Se ha terminado el tiempo de juego

    			// Se imprime que el jugador ha agotado el tiempo
    			xil_printf("\n\n\rSe ha agotado el tiempo.\n\r");

    			// Se imprime el mensaje de que se ha perdido
    			xil_printf("\nGAME OVER\n");

    			// Se imprime la frase en cuesti�n
    			xil_printf("\n\rLa frase era:\n\r");
    			Imprimir_Frase_Descubierta(frase, longitud);

    			// Se imprime el n�mero de aciertos
    			xil_printf("\n\rN�meros de aciertos: %d", numero_aciertos);

    			// Se imprime el n�meros de fallos
    			xil_printf("\n\rN�meros de fallos: %d", numero_fallos);

    			// Se imprime el tiempo de juego
    			xil_printf("\n\rTiempo de juego: %ds", tiempo_juego);
    			//xil_printf("\t");

    			// Se indica que el juego ha finalizado
    			fin_juego = 1;
    		}
    		// Si el juego a�n no ha acabado se incrementa la cuenta
    		else
			{
				// Se incrementa el tiempo de juego transcurrido
				tiempo_juego++;
			}
			// Se resetea la condici�n de la interrupci�n del FIT1
			intc_fit1 = 0;
    	}



    	// -------------------------------------------------------------------
		// Tratamiento del caso D) Comprobamos si ha tenido m�s fallos de los permitidos.
    	// -------------------------------------------------------------------
    	//
    	// Si ha cometido m�s fallos de los permitidos, el jugador pierde.
		// Se imprime la frase completa, n� de aciertos, n� de fallos y tiempo transcurrido.

		// Se comprueba si se ha alcanzado el n�mero de fallos m�ximo
		if (numero_fallos == maximo_fallos)
		{
			// Se ha cometido el n�mero de fallos m�ximo

			// Se imprime que el jugador ha agotado el n�mero de intentos
			xil_printf("\n\n\rSe ha agotado el n�mero de intentos.\n\r");

			// Se imprime el mensaje de que se ha perdido
			xil_printf("\nGAME OVER\n");

			// Se imprime la frase en cuesti�n
			xil_printf("\n\rLa frase era:\n\r");
			Imprimir_Frase_Descubierta(frase, longitud);

			// Se imprime el n�mero de aciertos
			xil_printf("\n\rN�meros de aciertos: %d", numero_aciertos);

			// Se imprime el n�meros de fallos
			xil_printf("\n\rN�meros de fallos: %d", numero_fallos);

			// Se imprime el tiempo de juego
			xil_printf("\n\rTiempo de juego: %ds", tiempo_juego);
			//xil_printf("\t");

			// Se indica que el juego ha finalizado
			fin_juego = 1;
		}
	}
	cleanup_platform();
	return 0;
}

// source ipcore_dir/microblaze_mcs_setup.tcl
// microblaze_mcs_data2mem workspace/hello_world/debug/hello_world.elf



