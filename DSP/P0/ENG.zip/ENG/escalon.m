function u=escalon(t)
% Unit step function

u=(t>=0); 
