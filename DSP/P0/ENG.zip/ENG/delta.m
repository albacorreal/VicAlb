function u=delta(t)
% Delta function
u=(t==0); 
