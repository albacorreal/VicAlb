function y=system2(x)
% System y[n]=(x[n])^2

% Salida/Output
y=x.^2;

