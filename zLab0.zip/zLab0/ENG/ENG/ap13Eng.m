%ap13 Figure plots for time-discrete signals
% Close figures and clear memory
close all;clear ;
% Definition of n axis (discrete time)
n=-10:10;

% Combination of pulse signals using time shifting
x1=pulsow(n,5)+ 2*escalon(n-5);
subplot(221);stem(n,x1,'b','linewidth',2);xlabel('discrete time, n'); ylabel(' x1[n] ');axis([-10 10 -1.2 2.2]);grid

% Combination of delta signals using time shifting
x2=-delta(n)+delta(n-1)+delta(n-2);
subplot(222);stem(n,x2,'b','linewidth',2);xlabel('discrete time, n'); ylabel(' x2[n] ');axis([-10 10 -1.2 1.2]);grid

% Combination of unit step functions using time scaling and shifting
x3=escalon(-n-1)+escalon(n-1);
subplot(223);stem(n,x3,'b','linewidth',2);xlabel('discrete time, n'); ylabel(' x3[n] ');axis([-10 10 -1.2 1.2]);grid

% Combination of a discrete time sinusoid and time scaling/shifting
A=1;
B=0;
x4=A*sin(pi*n/2+B);
subplot(224);stem(n,x4,'b','linewidth',2);xlabel('discrete time, n'); ylabel(' x4[n]');axis([-10 10 -1.2 1.2]);grid
