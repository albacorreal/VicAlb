% Combination of unit step and pulse signals
x1=2*escalon(n)-pulsow(n,4);
subplot(221);stem(n,x1,'b','linewidth',2);xlabel('discrete time, n'); ylabel(' x1[n] ');axis([-10 10 -1.2 2.2]);grid

% Combination of pulse and delta signals
x2=pulsow(n,3)-2*delta(n);
subplot(222);stem(n,x2,'b','linewidth',2);xlabel('discrete time, n'); ylabel(' x2[n] ');axis([-10 10 -1.2 1.2]);grid

% Combination of basic signals and constant values
x3=1-delta(n);
subplot(223);stem(n,x3,'b','linewidth',2);xlabel('discrete time, n'); ylabel(' x3[n] ');axis([-10 10 -1.2 1.2]);grid

% Combination of time disecrete sinusoid and constant amplitude shift
A=2;
B=-1;
x4=A*sin(pi*n/6)+B;
subplot(224);stem(n,x4,'b','linewidth',2);xlabel('discrete time, n'); ylabel(' x4[n]');axis([-10 10 -3.2 1.2]);grid