d1 = delta (n+2);
figure;stem(n,d1,'b','linewidth',2);xlabel('discrete time, n'); ylabel('d1[n]');axis([-10 10 -1.2 1.2]);grid

d2 = delta(n-2);
figure;stem(n,d2,'b','linewidth',2);xlabel('discrete time, n'); ylabel('d2[n]');axis([-10 10 -1.2 1.2]);grid

e1= escalon(-n-1);
figure;stem(n,e1,'b','linewidth',2);xlabel('discrete time, n'); ylabel('e1[n]');axis([-10 10 -1.2 1.2]);grid

e2 = escalon(-(n-1));
figure;stem(n,e2,'b','linewidth',2);xlabel('discrete time, n'); ylabel('e2[n]');axis([-10 10 -2.2 2.2]);grid

p1 = pulsow(2*n+3,8);
figure;stem(n,p1,'b','linewidth',2);xlabel('discrete time, n'); ylabel('p1[n]');axis([-10 10 -1.2 1.2]);grid

p2 = pulsow(-2*(n+1),6);
figure;stem(n,p2,'b','linewidth',2);xlabel('discrete time, n'); ylabel('p2[n]');axis([-10 10 -1.2 1.2]);grid

