% System combination

% Close figures and clear memory
close all;
Definitionn=-10:10;

figure;
x=pulsow(n,4);
y=system5(x);
subplot(311)
stem(n,x,'b','linewidth',2);  xlabel('discrete time, n'); ylabel(' x[n] ');
axis([-10 10 -1.5 1.5]);grid
subplot(312)
stem(n,y,'r','linewidth',2);  xlabel('discrete time, n'); ylabel(' y[n] ');
axis([-10 10 -4.5 4.5]);grid
subplot(313)
habc = delta(n-1)-2*delta(n-2)+4*delta(n-3)-3*delta(n-4)
stem(n,hb,'b','linewidth',2);  xlabel('discrete time, n'); ylabel(' habc[n] ');
axis([-10 10 -4 4]);grid

% SysA(z)*SysB(z)+SysC(z)
%2) IT IS A CAUSAL SYSTEM. 
%3) 3d[n]-2d[n-1]-2d[n-2}+3d[n-3]-9;