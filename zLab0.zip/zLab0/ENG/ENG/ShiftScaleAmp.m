e1 = -escalon(n); 
figure;stem(n,e1,'b','linewidth',2);xlabel('discrete time, n'); ylabel('e1[n]');axis([-10 10 -1.2 1.2]);grid

e2 = 2*escalon(n)-1;
figure;stem(n,e2,'b','linewidth',2);xlabel('discrete time, n'); ylabel('e2[n]');axis([-10 10 -1.2 1.2]);grid

p1 = -2*pulsow(n,3)+1;
figure;stem(n,p1,'b','linewidth',2);xlabel('discrete time, n'); ylabel('p1[n]');axis([-10 10 -1.2 1.2]);grid

p2 = 2*delta(n)-2;
figure;stem(n,p2,'b','linewidth',2);xlabel('discrete time, n'); ylabel('p2[n]');axis([-10 10 -2.2 2.2]);grid

